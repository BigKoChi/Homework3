package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.MemberDao;
import model.Member;
import util.DbConnection;

public class MemberDaoImpl implements MemberDao{

	public static void main(String[] args) {
//		Member m=new Member("M00","cfd","acd125",3000);
		MemberDaoImpl mdi=new MemberDaoImpl();
//		mdi.add(m);
		
		
//		MemberDaoImpl mdi=new MemberDaoImpl();
//		List<Member> al=new ArrayList<>();
//		al=mdi.selectAll();
//		System.out.println(al);
//		for(Member m:al)
//		{
//			System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getName()+" "+m.getPassword()+" "+m.getMoney());
//		}
		
		
//		MemberDaoImpl mdi=new MemberDaoImpl();
//		Member m=mdi.selectById(4);
//		System.out.println(m);
//		System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getName()+" "+m.getPassword()+" "+m.getMoney());
//	
		System.out.println(mdi.selectByMemberNo("a125"));
		
//		MemberDaoImpl mdi=new MemberDaoImpl();
//		Member m=mdi.selectByName("蔡");
//		System.out.println(m);
//		System.out.println(m.getId()+" "+m.getMemberNo()+" "+m.getName()+" "+m.getPassword()+" "+m.getMoney());

		
//		Member m=new Member("M00","cfd","acd125",3000);
//		MemberDaoImpl mdi=new MemberDaoImpl();
//		m.setId(1);
//		mdi.update(m);
		
		
//		mdi.delete(2);
	}

	Connection conn=DbConnection.getDb();
	@Override
	public void add(Member member) {
		String sql="insert into member(memberNo,name,password,money) values(?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,member.getMemberNo());
			ps.setString(2, member.getName());
			ps.setString(3, member.getPassword());
			ps.setInt(4, member.getMoney());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Member> selectAll() {
		String sql="select * from member";
		List<Member> l=new ArrayList<>();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				Member m=new Member();
				m.setId(rs.getInt("id"));
				m.setMemberNo(rs.getString("memberNo"));
				m.setName(rs.getString("name"));
				m.setPassword(rs.getString("password"));
				m.setMoney(rs.getInt("money"));
				l.add(m);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return l;
	}

	@Override
	public Member selectById(int id) {
		Member m=new Member();
		String sql="select * from member where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				m.setId(rs.getInt("id"));
				m.setMemberNo(rs.getString("memberNo"));
				m.setName(rs.getString("name"));
				m.setPassword(rs.getString("password"));
				m.setMoney(rs.getInt("money"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return m;
	}
	
	@Override
	public Member selectByMemberNo(String memberNo) {
		Member m=null;
		String sql="select * from member where memberNo=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, memberNo);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				m=new Member();
				m.setId(rs.getInt("id"));
				m.setMemberNo(rs.getString("memberNo"));
				m.setName(rs.getString("name"));
				m.setPassword(rs.getString("password"));
				m.setMoney(rs.getInt("money"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return m;
	}

	@Override
	public void update(Member member) {
		String sql="update member set memberNo=?,name=?,password=?,money=? where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1,member.getMemberNo());
			ps.setString(2, member.getName());
			ps.setString(3, member.getPassword());
			ps.setInt(4, member.getMoney());
			ps.setInt(5, member.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void delete(int id) {
		String sql="delete from member where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1,id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
