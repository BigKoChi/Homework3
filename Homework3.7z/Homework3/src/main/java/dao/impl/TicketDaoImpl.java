package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.TicketDao;
import model.Ticket;
import util.DbConnection;

public class TicketDaoImpl implements TicketDao{

	public static void main(String[] args) {
//		Ticket t=new Ticket("a002","M002","台北","台南",3,true,2224,10000,9957);
//		TicketDaoImpl mdi=new TicketDaoImpl();
//		mdi.add(t);
		
		
//		TicketDaoImpl mdi=new TicketDaoImpl();
//		List<Ticket> al=new ArrayList<>();
//		al=mdi.selectAll();
//		System.out.println(al);
//		for(Ticket m:al)
//		{
//			System.out.println(m.getId()+" "+m.getTicketNo()+" "+m.getMemberNo()+" "+m.getFromPlace()+" "+m.getGoPlace()+" "+m.getAmount()+" "+m.isGoandback()+" "+m.getCost()+" "+m.getMoneyBefore()+" "+m.getMoneyAfter());
//		}
		
		
//		TicketDaoImpl mdi=new TicketDaoImpl();
//		Ticket m=mdi.selectById(2);
//		System.out.println(m);
//		System.out.println(m.getId()+" "+m.getTicketNo()+" "+m.getMemberNo()+" "+m.getFromPlace()+" "+m.getGoPlace()+" "+m.getAmount()+" "+m.isGoandback()+" "+m.getCost()+" "+m.getMoneyBefore()+" "+m.getMoneyAfter());
	
		
//		Ticket t=new Ticket("a003","M003","台中","台東",1,false,1112,9000,957);
//		TicketDaoImpl mdi=new TicketDaoImpl();
//		t.setId(3);
//		mdi.update(t);
		
		
//		TicketDaoImpl mdi=new TicketDaoImpl();
//		mdi.delete(2);
		
		TicketDaoImpl mdi=new TicketDaoImpl();
		System.out.println(mdi.buycount("bb"));

	}
	Connection conn=DbConnection.getDb();
	@Override
	public void add(Ticket ticket) {
		String sql="insert into ticket(ticketNo,memberNo,fromplace,goplace,amount,goandback,cost,moneybefore,moneyafter) values(?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, ticket.getTicketNo());
			ps.setString(2, ticket.getMemberNo());
			ps.setString(3,ticket.getFromPlace());
			ps.setString(4,ticket.getGoPlace());
			ps.setInt(5, ticket.getAmount());
			ps.setBoolean(6, ticket.isGoandback());
			ps.setInt(7,ticket.getCost());
			ps.setInt(8, ticket.getMoneyBefore());
			ps.setInt(9, ticket.getMoneyAfter());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	@Override
	public List<Ticket> selectAll() {
		String sql="select * from ticket";
		List<Ticket> l=new ArrayList<>();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				Ticket t=new Ticket();
				t.setId(rs.getInt("id"));
				t.setTicketNo(rs.getString("ticketNo"));
				t.setMemberNo(rs.getString("memberNo"));
				t.setFromPlace(rs.getString("fromplace"));
				t.setGoPlace(rs.getString("goplace"));
				t.setAmount(rs.getInt("amount"));
				t.setGoandback(rs.getBoolean("goandback"));
				t.setCost(rs.getInt("cost"));
				t.setMoneyBefore(rs.getInt("moneybefore"));
				t.setMoneyAfter(rs.getInt("moneyafter"));
				l.add(t);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return l;
	}


	@Override
	public Ticket selectById(int id) {
		Ticket t=new Ticket();
		String sql="select * from ticket where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				t.setId(rs.getInt("id"));
				t.setTicketNo(rs.getString("ticketNo"));
				t.setMemberNo(rs.getString("memberNo"));
				t.setFromPlace(rs.getString("fromplace"));
				t.setGoPlace(rs.getString("goplace"));
				t.setAmount(rs.getInt("amount"));
				t.setGoandback(rs.getBoolean("goandback"));
				t.setCost(rs.getInt("cost"));
				t.setMoneyBefore(rs.getInt("moneybefore"));
				t.setMoneyAfter(rs.getInt("moneyafter"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return t;
	}


	@Override
	public void update(Ticket ticket) {
		String sql="update ticket set ticketNo=?,memberNo=?,fromplace=?,goplace=?,amount=?,goandback=?,cost=?,moneybefore=?,moneyafter=? where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, ticket.getTicketNo());
			ps.setString(2, ticket.getMemberNo());
			ps.setString(3,ticket.getFromPlace());
			ps.setString(4,ticket.getGoPlace());
			ps.setInt(5, ticket.getAmount());
			ps.setBoolean(6, ticket.isGoandback());
			ps.setInt(7,ticket.getCost());
			ps.setInt(8, ticket.getMoneyBefore());
			ps.setInt(9, ticket.getMoneyAfter());
			ps.setInt(10, ticket.getId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public void delete(int id) {
		String sql="delete from ticket where id=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setInt(1,id);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	@Override
	public int buycount(String memberNo) {
		String sql="select memberNo,count(memberNo) as count from ticket group by memberNo having memberNo=?";
		int number=0;
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, memberNo);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				number=rs.getInt("count");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return number;
	}


	
	
}
