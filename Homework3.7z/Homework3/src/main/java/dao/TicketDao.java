package dao;

import java.util.List;

import model.Ticket;

public interface TicketDao {
	//create
	void add(Ticket ticket);
	//read
	List<Ticket> selectAll();
	Ticket selectById(int id);
	int buycount(String memberNo);
	//update
	void update(Ticket ticket);
	//delete
	void delete(int id);
}
