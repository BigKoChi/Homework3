package dao;

import java.util.List;

import model.Member;

public interface MemberDao {
	//create
	void add(Member member);
	//read
	List<Member> selectAll();
	Member selectById(int id);
	Member selectByMemberNo(String memberNo);
	void update(Member member);
	//delete
	void delete(int id);

}
