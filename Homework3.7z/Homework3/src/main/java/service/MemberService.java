package service;

import java.util.List;

import model.Member;

public interface MemberService {
	//create
	boolean addMember(Member member);
	//read
	List<Member> findAllMember();
	boolean loginCheck(String memberNo,String password);
	Member findById(int id);
	//update
	boolean updateMember(Member member);
	//delete
	boolean deleteMember(int id);
}
