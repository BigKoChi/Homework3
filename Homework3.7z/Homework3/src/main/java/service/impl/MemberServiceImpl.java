package service.impl;

import java.util.ArrayList;
import java.util.List;

import dao.impl.MemberDaoImpl;
import model.Member;
import service.MemberService;

public class MemberServiceImpl implements MemberService {

	public static void main(String[] args) {
		//Member m=new Member("a125","e456","d789",3500);
		MemberServiceImpl msi=new MemberServiceImpl();
		//System.out.println(msi.addMember(m));
		
//		List<Member> ml=msi.findAllMember();
//		for(Member mo:ml)
//		{
//			System.out.println(mo.getId()+" "+mo.getMemberNo());
//		}
		
		System.out.println(msi.loginCheck("a125","d789"));
		
		//m.setId(2);
		//msi.updateMember(m);
		//System.out.println(msi.updateMember(m));
		
		//System.out.println(msi.deleteMember(2));
		
		
		
	}

	MemberDaoImpl mdi=new MemberDaoImpl();
	@Override
	public boolean addMember(Member member) {
		boolean b=false;
		Member m=mdi.selectByMemberNo(member.getMemberNo());
		if(m==null) 
		{
			mdi.add(member);
			b=true;
		}
		return b;
		
	}
	@Override
	public List<Member> findAllMember() {
		List<Member> al=new ArrayList<>();
		al=mdi.selectAll();
		return al;
	}
	
	@Override
	public boolean loginCheck(String memberNo, String password) {
		boolean b=false;
		Member m=mdi.selectByMemberNo(memberNo);
		if(m!=null && m.getPassword().equals(password)) 
		{
			b=true;
		}
		return b;
	}
	
	@Override
	public boolean updateMember(Member member) {
		boolean b=false;
		Member m=mdi.selectById(member.getId());
		if(m.getId()!=0) 
		{
			mdi.update(member);
			b=true;
		}
		return b;
	}

	@Override
	public boolean deleteMember(int id) {
		boolean b=false;
		Member m=mdi.selectById(id);
		if(m.getId()!=0) 
		{
			mdi.delete(id);
			b=true;
		}
		return b;
	}
	@Override
	public Member findById(int id) {
		Member m=mdi.selectById(id);
		return m;
	}
	

}
