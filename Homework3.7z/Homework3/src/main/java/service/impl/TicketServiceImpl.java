package service.impl;

import java.util.ArrayList;
import java.util.List;

import dao.impl.TicketDaoImpl;
import model.Ticket;
import service.TicketService;

public class TicketServiceImpl implements TicketService{

	public static void main(String[] args) {
		Ticket t=new Ticket("123","cb","1","2",1,false,100,552,200);
		t.setId(3);
		TicketServiceImpl tsi=new TicketServiceImpl();
//		tsi.addTicket(t);
		
		List<Ticket> tl=tsi.findAllTicket();
		for(Ticket to:tl)
		{
			System.out.println(to.getId()+" "+to.getTicketNo());
		}
		
//		System.out.println(tsi.updateTicket(t));
//		System.out.println(tsi.deleteTicket(3));
		
	}
	
	TicketDaoImpl tdi=new TicketDaoImpl();
	@Override
	public void addTicket(Ticket ticket) {
		
			tdi.add(ticket);

	}

	@Override
	public List<Ticket> findAllTicket() {
		List<Ticket> al=new ArrayList<>();
		al=tdi.selectAll();
		return al;
	}

	@Override
	public boolean updateTicket(Ticket ticket) {
		boolean b=false;
		Ticket t=tdi.selectById(ticket.getId());
		if(t.getId()!=0) 
		{
			tdi.update(ticket);
			b=true;
		}
		return b;
	}

	@Override
	public boolean deleteTicket(int id) {
		boolean b=false;
		Ticket t=tdi.selectById(id);
		if(t.getId()!=0) 
		{
			tdi.delete(id);
			b=true;
		}
		return b;
	}

	@Override
	public Ticket findById(int id) {
		Ticket t=tdi.selectById(id);
		return t;
	}

	
}
