package service;

import java.util.List;

import model.Ticket;

public interface TicketService {
	//create
	void addTicket(Ticket ticket);
	//read
	List<Ticket> findAllTicket();
	Ticket findById(int id);
	//update
	boolean updateTicket(Ticket ticket);
	//delete
	boolean deleteTicket(int id);
}