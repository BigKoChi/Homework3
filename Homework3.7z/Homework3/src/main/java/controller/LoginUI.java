package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.impl.MemberDaoImpl;
import model.Member;
import model.Ticket;
import service.impl.MemberServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class LoginUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_memberNo;
	private JPasswordField passwordField;
	
	public static Member member; //顯示user message在Label上
	public static Ticket ticket;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI frame = new LoginUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 417, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(64, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(26, 10, 347, 241);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("瞬間移動 訂票系統");
		lblNewLabel.setFont(new Font("新細明體", Font.BOLD, 18));
		lblNewLabel.setBounds(105, 10, 269, 36);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("帳號:");
		lblNewLabel_1.setBounds(84, 85, 46, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("密碼:");
		lblNewLabel_2.setBounds(84, 126, 46, 15);
		panel.add(lblNewLabel_2);
		
		textField_memberNo = new JTextField();
		textField_memberNo.setBounds(126, 83, 96, 18);
		panel.add(textField_memberNo);
		textField_memberNo.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(126, 124, 96, 18);
		panel.add(passwordField);
		
		JLabel lblNewLabel_3 = new JLabel("管理者 admin/admin");
		lblNewLabel_3.setBounds(212, 217, 125, 15);
		panel.add(lblNewLabel_3);
	
		
		/****************按鈕區*****************/
		JButton Button_register = new JButton("會員註冊");
		Button_register.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MemberUI mu=new MemberUI();
				mu.setVisible(true);
				dispose();
			}
		});
		Button_register.setBounds(61, 184, 87, 23);
		panel.add(Button_register);
		
		JButton Button_login = new JButton("登入");
		Button_login.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				MemberServiceImpl msi=new MemberServiceImpl();
				String memberNo=textField_memberNo.getText();
				String password=new String(passwordField.getPassword());
				
				if(memberNo.equals("admin") && password.equals("admin"))
				{
					AdminUI adminUi=new AdminUI();
					adminUi.setVisible(true);
					dispose();
				}
				else if(msi.loginCheck(memberNo,password))
				{
					LoginUI.member=new MemberDaoImpl().selectByMemberNo(memberNo);
	
					TicketUI tu=new TicketUI();
					tu.setVisible(true);
					dispose();
				}
				else 
				{
					JOptionPane.showMessageDialog(Button_login, "帳號密碼錯誤!");
				}
			}
		});
		Button_login.setBounds(202, 184, 87, 23);
		panel.add(Button_login);
		
		

	}
}
