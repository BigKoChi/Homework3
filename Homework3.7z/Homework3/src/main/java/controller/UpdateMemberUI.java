package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import service.impl.MemberServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class UpdateMemberUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_name;
	private JTextField textField_password;
	private JTextField textField_money;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateMemberUI frame = new UpdateMemberUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateMemberUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 184);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(64, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(10, 10, 414, 128);
		contentPane.add(panel);
		
		JLabel lblNewLabel = new JLabel("會員資料:");
		lblNewLabel.setBounds(10, 10, 71, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID:");
		lblNewLabel_1.setBounds(20, 38, 46, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("帳號:");
		lblNewLabel_1_1.setBounds(20, 66, 46, 15);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("姓名:");
		lblNewLabel_1_2.setBounds(20, 94, 46, 15);
		panel.add(lblNewLabel_1_2);
		
		textField_name = new JTextField(LoginUI.member.getName());
		textField_name.setColumns(10);
		textField_name.setBounds(69, 91, 96, 21);
		panel.add(textField_name);
		
		JLabel lblNewLabel_1_3 = new JLabel("密碼:");
		lblNewLabel_1_3.setBounds(186, 38, 46, 15);
		panel.add(lblNewLabel_1_3);
		
		textField_password = new JTextField(LoginUI.member.getPassword());
		textField_password.setColumns(10);
		textField_password.setBounds(235, 35, 96, 21);
		panel.add(textField_password);
		
		JLabel lblNewLabel_1_4 = new JLabel("儲值金:");
		lblNewLabel_1_4.setBounds(186, 66, 46, 15);
		panel.add(lblNewLabel_1_4);
		
		textField_money = new JTextField(LoginUI.member.getMoney()+"");
		textField_money.setColumns(10);
		textField_money.setBounds(235, 63, 96, 21);
		panel.add(textField_money);
		
		JLabel Label_memberID = new JLabel(""+LoginUI.member.getId());
		Label_memberID.setBounds(70, 35, 82, 15);
		panel.add(Label_memberID);
		
		JLabel Label_memberNo = new JLabel(LoginUI.member.getMemberNo());
		Label_memberNo.setBounds(69, 66, 82, 15);
		panel.add(Label_memberNo);

		
		
		/*************按鈕區***********/
		MemberServiceImpl msi=new MemberServiceImpl();
		
		JButton Button_memberOK = new JButton("送出");
		Button_memberOK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LoginUI.member.setName(textField_name.getText());
				LoginUI.member.setPassword(textField_password.getText());
				LoginUI.member.setMoney(Integer.valueOf(textField_money.getText()));
				msi.updateMember(LoginUI.member);
				JOptionPane.showMessageDialog(Button_memberOK, "已修改，請重新查詢");
				dispose();
			}
		});
		Button_memberOK.setBounds(218, 95, 87, 23);
		panel.add(Button_memberOK);
		
		JButton Button_memberback = new JButton("取消");
		Button_memberback.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		Button_memberback.setBounds(315, 95, 87, 23);
		panel.add(Button_memberback);
		
		
	}
}
