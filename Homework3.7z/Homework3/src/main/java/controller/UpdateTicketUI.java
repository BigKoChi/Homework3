package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import service.impl.TicketServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JCheckBox;
import java.awt.Color;

public class UpdateTicketUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_cost;
	private JTextField textField_amount;
	private JTextField textField_goplace;
	private JTextField textField_fromplace;
	private JTextField textField_moneybefore;
	private JTextField textField_moneyafter;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateTicketUI frame = new UpdateTicketUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateTicketUI() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 310);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(64, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//Label_memberID.setText(LoginUI.member.getId()+"");
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 10, 414, 251);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("訂單資料:");
		lblNewLabel_2.setBounds(10, 10, 71, 15);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1_5 = new JLabel("ID:");
		lblNewLabel_1_5.setBounds(20, 38, 46, 15);
		panel_1.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("訂單號:");
		lblNewLabel_1_1_1.setBounds(20, 66, 46, 15);
		panel_1.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("來回:");
		lblNewLabel_1_3_1.setBounds(20, 206, 46, 15);
		panel_1.add(lblNewLabel_1_3_1);
		
		textField_cost = new JTextField(LoginUI.ticket.getCost()+"");
		textField_cost.setColumns(10);
		textField_cost.setBounds(256, 38, 96, 21);
		panel_1.add(textField_cost);
		
		JLabel lblNewLabel_1_4_1 = new JLabel("費用:");
		lblNewLabel_1_4_1.setBounds(187, 41, 46, 15);
		panel_1.add(lblNewLabel_1_4_1);
		
		JLabel lblNewLabel_1_6 = new JLabel("出發地:");
		lblNewLabel_1_6.setBounds(20, 122, 46, 15);
		panel_1.add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("目的地:");
		lblNewLabel_1_1_2.setBounds(20, 150, 46, 15);
		panel_1.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_2_2 = new JLabel("票數:");
		lblNewLabel_1_2_2.setBounds(20, 178, 46, 15);
		panel_1.add(lblNewLabel_1_2_2);
		
		textField_amount = new JTextField(LoginUI.ticket.getAmount()+"");
		textField_amount.setColumns(10);
		textField_amount.setBounds(69, 175, 96, 21);
		panel_1.add(textField_amount);
		
		textField_goplace = new JTextField(LoginUI.ticket.getGoPlace());
		textField_goplace.setColumns(10);
		textField_goplace.setBounds(69, 147, 96, 21);
		panel_1.add(textField_goplace);
		
		textField_fromplace = new JTextField(LoginUI.ticket.getFromPlace());
		textField_fromplace.setColumns(10);
		textField_fromplace.setBounds(69, 119, 96, 21);
		panel_1.add(textField_fromplace);
		
		JLabel lblNewLabel_1_3_2 = new JLabel("扣款前金額:");
		lblNewLabel_1_3_2.setBounds(187, 66, 76, 15);
		panel_1.add(lblNewLabel_1_3_2);
		
		textField_moneybefore = new JTextField(LoginUI.ticket.getMoneyBefore()+"");
		textField_moneybefore.setColumns(10);
		textField_moneybefore.setBounds(256, 63, 96, 21);
		panel_1.add(textField_moneybefore);
		
		textField_moneyafter = new JTextField(LoginUI.ticket.getMoneyAfter()+"");
		textField_moneyafter.setColumns(10);
		textField_moneyafter.setBounds(256, 91, 96, 21);
		panel_1.add(textField_moneyafter);
		
		JLabel lblNewLabel_1_4_2 = new JLabel("扣款後金額:");
		lblNewLabel_1_4_2.setBounds(187, 94, 76, 15);
		panel_1.add(lblNewLabel_1_4_2);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("會員帳號:");
		lblNewLabel_1_1_1_1.setBounds(10, 94, 61, 15);
		panel_1.add(lblNewLabel_1_1_1_1);
		
		JLabel Label_ticketID = new JLabel(""+LoginUI.ticket.getId());
		Label_ticketID.setBounds(69, 38, 96, 15);
		panel_1.add(Label_ticketID);
		
		JLabel Label_memberNo = new JLabel(LoginUI.ticket.getMemberNo());
		Label_memberNo.setBounds(69, 97, 96, 15);
		panel_1.add(Label_memberNo);
		
		JLabel Label_ticketNo = new JLabel(LoginUI.ticket.getTicketNo());
		Label_ticketNo.setBounds(69, 66, 96, 15);
		panel_1.add(Label_ticketNo);
		
		JCheckBox CheckBox = new JCheckBox("");
		CheckBox.setBounds(68, 202, 97, 23);
		panel_1.add(CheckBox);
		
		if(LoginUI.ticket.isGoandback()) 
			CheckBox.setSelected(true);

		
			
		/*************按鈕區***********/
		
		TicketServiceImpl tsi=new TicketServiceImpl();
		
		JButton Button_ticketOK = new JButton("送出");
		Button_ticketOK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LoginUI.ticket.setFromPlace(textField_fromplace.getText());
				LoginUI.ticket.setGoPlace(textField_goplace.getText());
				LoginUI.ticket.setAmount(Integer.valueOf(textField_amount.getText()));
				boolean b=false;
				if(CheckBox.isSelected()) 
					b=true;
				LoginUI.ticket.setGoandback(b);
				LoginUI.ticket.setCost(Integer.valueOf(textField_cost.getText()));
				LoginUI.ticket.setMoneyBefore(Integer.valueOf(textField_moneybefore.getText()));
				LoginUI.ticket.setMoneyAfter(Integer.valueOf(textField_moneyafter.getText()));
				tsi.updateTicket(LoginUI.ticket);
				JOptionPane.showMessageDialog(Button_ticketOK, "已修改，請重新查詢");
				dispose();
			}
		});
		Button_ticketOK.setBounds(220, 218, 87, 23);
		panel_1.add(Button_ticketOK);
		
		JButton Button_ticketback = new JButton("取消");
		Button_ticketback.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		Button_ticketback.setBounds(317, 218, 87, 23);
		panel_1.add(Button_ticketback);
		
		
		
		
	}
}
