package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.impl.TicketDaoImpl;
import model.Ticket;
import service.impl.MemberServiceImpl;
import service.impl.TicketServiceImpl;
import util.Tool;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import javax.swing.Timer;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.SpinnerNumberModel;
import javax.swing.JScrollPane;

public class TicketUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	public String fplace="";
	public String gplace="";
	private JTextField textField_topup;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private JRadioButton radio_gtaipei;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TicketUI frame = new TicketUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TicketUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 521, 359);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(64, 128, 128));
		panel.setBounds(0, 10, 505, 300);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel Label_welcome = new JLabel("");
		Label_welcome.setBounds(10, 10, 323, 28);
		panel.add(Label_welcome);
		Label_welcome.setText(LoginUI.member.getName()+" 歡迎使用，您目前餘額尚有:"+LoginUI.member.getMoney());
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 128, 0));
		panel_1.setBounds(20, 48, 313, 132);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("出發地:");
		lblNewLabel_1.setBounds(10, 29, 46, 15);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("目的地:");
		lblNewLabel_2.setBounds(10, 64, 46, 15);
		panel_1.add(lblNewLabel_2);
		
		JRadioButton Radio_ftaipei = new JRadioButton("台北");
		Radio_ftaipei.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Radio_ftaipei.isSelected()) {
					fplace="台北";
				}
			}
		});
		buttonGroup.add(Radio_ftaipei);
		Radio_ftaipei.setBounds(69, 25, 55, 23);
		panel_1.add(Radio_ftaipei);
		
		JRadioButton Radio_ftaichung = new JRadioButton("台中");
		Radio_ftaichung.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Radio_ftaichung.isSelected())
					fplace="台中";
			}
		});
		buttonGroup.add(Radio_ftaichung);
		Radio_ftaichung.setBounds(126, 25, 55, 23);
		panel_1.add(Radio_ftaichung);
		
		JRadioButton Radio_ftainan = new JRadioButton("台南");
		Radio_ftainan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Radio_ftainan.isSelected())
					fplace="台南";
			}
		});
		buttonGroup.add(Radio_ftainan);
		Radio_ftainan.setBounds(183, 25, 55, 23);
		panel_1.add(Radio_ftainan);
		
		JRadioButton Radio_ftaitung = new JRadioButton("台東");
		Radio_ftaitung.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Radio_ftaitung.isSelected())
					fplace="台東";
			}
		});
		buttonGroup.add(Radio_ftaitung);
		Radio_ftaitung.setBounds(240, 25, 55, 23);
		panel_1.add(Radio_ftaitung);
		
	
		radio_gtaipei = new JRadioButton("台北");
		radio_gtaipei.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(radio_gtaipei.isSelected())
					gplace="台北";
			}
		});
		buttonGroup_1.add(radio_gtaipei);
		radio_gtaipei.setBounds(69, 56, 55, 23);
		panel_1.add(radio_gtaipei);
		
		JRadioButton Radio_gtaichung = new JRadioButton("台中");
		Radio_gtaichung.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Radio_gtaichung.isSelected())
					gplace="台中";
			}
		});
		buttonGroup_1.add(Radio_gtaichung);
		Radio_gtaichung.setBounds(126, 56, 55, 23);
		panel_1.add(Radio_gtaichung);
		
		JRadioButton Radio_gtainan = new JRadioButton("台南");
		Radio_gtainan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Radio_gtainan.isSelected())
					gplace="台南";
			}
		});
		buttonGroup_1.add(Radio_gtainan);
		Radio_gtainan.setBounds(183, 56, 55, 23);
		panel_1.add(Radio_gtainan);
		
		JRadioButton Radio_gtaitung = new JRadioButton("台東");
		Radio_gtaitung.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(Radio_gtaitung.isSelected())
					gplace="台東";
			}
		});
		buttonGroup_1.add(Radio_gtaitung);
		Radio_gtaitung.setBounds(240, 56, 55, 23);
		panel_1.add(Radio_gtaitung);
		
		
		JLabel lblNewLabel_3 = new JLabel("張數:");
		lblNewLabel_3.setBounds(10, 101, 46, 15);
		panel_1.add(lblNewLabel_3);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
		spinner.setBounds(51, 98, 30, 22);
		panel_1.add(spinner);
		
		JCheckBox chckBox_goandback = new JCheckBox("來回");
		chckBox_goandback.setBounds(100, 97, 62, 23);
		panel_1.add(chckBox_goandback);
		
		JLabel lblNewLabel_4 = new JLabel("站與站 票價為3000元");
		lblNewLabel_4.setBounds(183, 85, 139, 15);
		panel_1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_msg = new JLabel("需x張數(來回需再x2)。");
		lblNewLabel_msg.setBounds(183, 117, 139, 15);
		panel_1.add(lblNewLabel_msg);
		
		JLabel lblNewLabel_4_1 = new JLabel("ex.台北-台南:6000元");
		lblNewLabel_4_1.setBounds(183, 101, 139, 15);
		panel_1.add(lblNewLabel_4_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 190, 322, 100);
		panel.add(scrollPane);
		
		JTextArea textArea_output = new JTextArea();
		scrollPane.setViewportView(textArea_output);
		
		JLabel Label_timer = new JLabel("");
		Label_timer.setBounds(347, 17, 138, 15);
		panel.add(Label_timer);
		
		Timer timer=new Timer(1000,e->{
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("YYYY/MM/dd HH:mm:ss");
			LocalDateTime ldt=LocalDateTime.now();
			String nowTime=ldt.format(dtf);
			Label_timer.setText(nowTime);
		});
		timer.start();
		
		JLabel lblNewLabel = new JLabel("金額:");
		lblNewLabel.setBounds(351, 85, 46, 15);
		panel.add(lblNewLabel);
		
		textField_topup = new JTextField();
		textField_topup.setBounds(389, 82, 96, 21);
		panel.add(textField_topup);
		textField_topup.setColumns(10);
		
		/************按鈕區**************/
		JButton Button_OK = new JButton("送出");
		Button_OK.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				TicketServiceImpl tsi=new TicketServiceImpl();
				Ticket t=new Ticket();
				int count=new TicketDaoImpl().buycount(LoginUI.member.getMemberNo());
				t.setTicketNo(LoginUI.member.getMemberNo()+"-"+(count+1));
				t.setMemberNo(LoginUI.member.getMemberNo());
				t.setFromPlace(fplace);
				t.setGoPlace(gplace);
				t.setAmount((int)spinner.getValue());
				t.setGoandback(chckBox_goandback.isSelected());
				t.setMoneyBefore(LoginUI.member.getMoney());
				Tool tool=new Tool();
				LoginUI.ticket=tool.Calculate(t);
				if(LoginUI.ticket!=null) 
				{
					tsi.addTicket(LoginUI.ticket);
					LoginUI.member.setMoney(LoginUI.ticket.getMoneyAfter());
					new MemberServiceImpl().updateMember(LoginUI.member);
					String output=tool.show(LoginUI.ticket);
					textArea_output.setText(output);
					Label_welcome.setText(LoginUI.member.getName()+" 歡迎使用，您目前餘額尚有:"+LoginUI.member.getMoney());
				}
				else 
				{
					JOptionPane.showMessageDialog(Button_OK, "餘額不足，麻煩請儲值。");
				}
			}
		});
		Button_OK.setBounds(370, 168, 87, 23);
		panel.add(Button_OK);
		
		JButton Button_back = new JButton("切換會員");
		Button_back.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LoginUI lu=new LoginUI();
				lu.setVisible(true);
				dispose();
			}
		});
		Button_back.setBounds(370, 234, 87, 23);
		panel.add(Button_back);
		
		JButton Button_exit = new JButton("離開");
		Button_exit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
			}
		});
		Button_exit.setBounds(370, 267, 87, 23);
		panel.add(Button_exit);
		
		
		
		JButton Button_topup = new JButton("儲值");
		Button_topup.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				int topupMoney=LoginUI.member.getMoney()+Integer.parseInt(textField_topup.getText());
				LoginUI.member.setMoney(topupMoney);
				new MemberServiceImpl().updateMember(LoginUI.member);
				Label_welcome.setText(LoginUI.member.getName()+" 歡迎使用，您目前餘額尚有:"+LoginUI.member.getMoney());
				JOptionPane.showMessageDialog(Button_topup, "儲值成功。");
			}
		});
		Button_topup.setBounds(422, 118, 63, 23);
		panel.add(Button_topup);
		
		JButton Button_print = new JButton("列印");
		Button_print.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					textArea_output.print();
				} catch (PrinterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		Button_print.setBounds(370, 201, 87, 23);
		panel.add(Button_print);

	}
}
