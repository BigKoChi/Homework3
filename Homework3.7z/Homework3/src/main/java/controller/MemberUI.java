package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Member;
import service.impl.MemberServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;

public class MemberUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_memberNo;
	private JTextField textField_name;
	private JTextField textField_password;
	private JTextField textField_money;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MemberUI frame = new MemberUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MemberUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 425, 286);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(64, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(192, 192, 192));
		panel.setBounds(32, 10, 351, 218);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("帳號:");
		lblNewLabel.setBounds(41, 37, 46, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("姓名:");
		lblNewLabel_1.setBounds(41, 78, 46, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("密碼:");
		lblNewLabel_2.setBounds(41, 120, 46, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("儲值金額:");
		lblNewLabel_3.setBounds(22, 164, 65, 15);
		panel.add(lblNewLabel_3);
		
		textField_memberNo = new JTextField();
		textField_memberNo.setBounds(97, 34, 96, 21);
		panel.add(textField_memberNo);
		textField_memberNo.setColumns(10);
		
		textField_name = new JTextField();
		textField_name.setBounds(97, 75, 96, 21);
		panel.add(textField_name);
		textField_name.setColumns(10);
		
		textField_password = new JTextField();
		textField_password.setBounds(97, 117, 96, 21);
		panel.add(textField_password);
		textField_password.setColumns(10);
		
		textField_money = new JTextField();
		textField_money.setBounds(97, 161, 96, 21);
		panel.add(textField_money);
		textField_money.setColumns(10);
		
		/***************按鈕區**************/
		JButton Button_register = new JButton("註冊");
		Button_register.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Member m=new Member();
				m.setMemberNo(textField_memberNo.getText());
				m.setName(textField_name.getText());
				m.setPassword(textField_password.getText());
				m.setMoney(Integer.parseInt(textField_money.getText()));
				MemberServiceImpl msi=new MemberServiceImpl();
				if(msi.addMember(m))
				{
					JOptionPane.showMessageDialog(Button_register, "新增成功");
					LoginUI lu=new LoginUI();
					lu.setVisible(true);
					dispose();
				}
				else 
				{
					JOptionPane.showMessageDialog(Button_register, "帳號已註冊");
				}
			}
		});
		Button_register.setBounds(254, 148, 87, 23);
		panel.add(Button_register);
		
		JButton Button_cancel = new JButton("取消");
		Button_cancel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LoginUI lu=new LoginUI();
				lu.setVisible(true);
				dispose();
			}
		});
		Button_cancel.setBounds(254, 185, 87, 23);
		panel.add(Button_cancel);

	}
}
