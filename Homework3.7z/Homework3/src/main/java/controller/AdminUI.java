package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Member;
import model.Ticket;
import service.impl.MemberServiceImpl;
import service.impl.TicketServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;
import java.util.List;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Color;

public class AdminUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField_id;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminUI frame = new AdminUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 495, 443);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192, 192, 192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(64, 128, 128));
		panel.setBounds(10, 10, 459, 384);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 259, 439, 115);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID:");
		lblNewLabel.setBounds(10, 48, 32, 15);
		panel_1.add(lblNewLabel);
		
		textField_id = new JTextField();
		textField_id.setBounds(32, 45, 64, 21);
		panel_1.add(textField_id);
		textField_id.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 23, 437, 226);
		panel.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		scrollPane.setViewportView(textArea);

		
		/****************按鈕區*****************/
		MemberServiceImpl msi=new MemberServiceImpl();
		TicketServiceImpl tsi=new TicketServiceImpl();
		JButton Button_allmember = new JButton("查詢會員資料");
		Button_allmember.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				List<Member> alm=msi.findAllMember();
				textArea.setText("ID\t帳號\t姓名\t密碼\t儲值金");
				for(Member m:alm) 
				{
					textArea.append("\n"+m.getId()+"\t"+m.getMemberNo()+"\t"+m.getName()+"\t"+m.getPassword()+"\t"+m.getMoney());
				}
			}
		});
		Button_allmember.setBounds(106, 10, 116, 23);
		panel_1.add(Button_allmember);
		
		JButton Button_allticket = new JButton("查詢訂單資料");
		Button_allticket.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				List<Ticket> alt=tsi.findAllTicket();
				textArea.setText("ID\t訂單號\t會員\t出發地\t目的地\t張數\t來回\t費用\t扣款前金額\t扣款後金額");
				for(Ticket t:alt) 
				{
					textArea.append("\n"+t.getId()+
							"\t"+t.getTicketNo()+
							"\t"+t.getMemberNo()+
							"\t"+t.getFromPlace()+
							"\t"+t.getGoPlace()+
							"\t"+t.getAmount()+
							"\t"+t.isGoandback()+
							"\t"+t.getCost()+
							"\t"+t.getMoneyBefore()+
							"\t"+t.getMoneyAfter());
				}
			}
		});
		
		Button_allticket.setBounds(232, 10, 116, 23);
		panel_1.add(Button_allticket);
		
		JButton Button_deletemember = new JButton("刪除會員資料");
		Button_deletemember.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!textField_id.getText().equals("")) 
				{
				msi.deleteMember(Integer.valueOf(textField_id.getText()));
				JOptionPane.showMessageDialog(Button_deletemember, "已刪除，請重新查詢");
				}
				else
					JOptionPane.showMessageDialog(Button_deletemember, "請輸入ID");
			}
		});
		Button_deletemember.setBounds(106, 77, 120, 23);
		panel_1.add(Button_deletemember);
		
		JButton Button_deleteticket = new JButton("刪除訂單資料");
		Button_deleteticket.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {		
				if(!textField_id.getText().equals("")) 
				{
				tsi.deleteTicket(Integer.valueOf(textField_id.getText()));
				JOptionPane.showMessageDialog(Button_deletemember, "已刪除，請重新查詢");
				}
				else
					JOptionPane.showMessageDialog(Button_deletemember, "請輸入ID");
			}
		});
		Button_deleteticket.setBounds(232, 77, 120, 23);
		panel_1.add(Button_deleteticket);
		
		JButton btnNewButton = new JButton("登出");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				LoginUI loginui=new LoginUI();
				loginui.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(375, 77, 64, 23);
		panel_1.add(btnNewButton);
		
		JButton Button_updatemember = new JButton("修改會員資料");
		Button_updatemember.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!textField_id.getText().equals("")) 
				{
					LoginUI.member=msi.findById(Integer.valueOf(textField_id.getText()));
					new UpdateMemberUI().setVisible(true);
				}
				else
					JOptionPane.showMessageDialog(Button_deletemember, "請輸入ID");
			}
		});
		Button_updatemember.setBounds(106, 43, 120, 23);
		panel_1.add(Button_updatemember);
		
		JButton Button_updateticket = new JButton("修改訂單資料");
		Button_updateticket.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(!textField_id.getText().equals("")) 
				{
					LoginUI.ticket=tsi.findById(Integer.valueOf(textField_id.getText()));
					new UpdateTicketUI().setVisible(true);	
				}
				else
					JOptionPane.showMessageDialog(Button_deletemember, "請輸入ID");
			}
		});
		Button_updateticket.setBounds(232, 41, 120, 23);
		panel_1.add(Button_updateticket);
		
		JButton Button_print = new JButton("列印");
		Button_print.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					textArea.print();
				} catch (PrinterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		Button_print.setBounds(375, 44, 64, 23);
		panel_1.add(Button_print);
		
		
		
		
	}
}
