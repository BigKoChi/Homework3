package util;

import model.Ticket;

public class Tool {

	public Ticket Calculate(Ticket ticket) 
	{
		int fromPlace=0;
		int goPlace=0;
		switch(ticket.getFromPlace())
		{
			case "台北":fromPlace=1;break;
			case "台中":fromPlace=2;break;
			case "台南":fromPlace=3;break;
			case "台東":fromPlace=4;break;
		}
		switch(ticket.getGoPlace()) 
		{
			case "台北":goPlace=1;break;
			case "台中":goPlace=2;break;
			case "台南":goPlace=3;break;
			case "台東":goPlace=4;break;
		}
		
		
		int range=Math.abs(goPlace-fromPlace);
		int goandback=1;
		if(ticket.isGoandback())
			goandback=2;
		int cost=range*3000*ticket.getAmount()*goandback;
			
		Ticket t=null;	
		if(ticket.getMoneyBefore()>=cost) 
		{
			t=new Ticket();
			t.setTicketNo(ticket.getTicketNo());
			t.setMemberNo(ticket.getMemberNo());
			t.setFromPlace(ticket.getFromPlace());
			t.setGoPlace(ticket.getGoPlace());
			t.setAmount(ticket.getAmount());
			t.setGoandback(ticket.isGoandback());
			t.setCost(cost);
			t.setMoneyBefore(ticket.getMoneyBefore());
			t.setMoneyAfter(ticket.getMoneyBefore()-cost);
		}
		return t;
	};
	
	
	public String show(Ticket ticket) 
	{
	
		String goandback="";	
		if(ticket.isGoandback())
			goandback="來回";
		else
			goandback="單程";
		
		String s="感謝使用本系統"
				+ "\n==============================================\n"
				+ "您已訂購從 "+ticket.getFromPlace()+" 到 "+ticket.getGoPlace()+" "+goandback+" 票 "+ticket.getAmount()+"張。\n"
				+ "總共金額為: "+ticket.getCost()+
				"\n=================================================\n"
				+"剩餘金額為: "+ticket.getMoneyAfter();
		return s;
		
	}
	
}
