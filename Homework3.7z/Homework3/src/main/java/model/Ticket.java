package model;

public class Ticket {

	private int id;
	private String ticketNo;
	private String memberNo;
	private String fromPlace;
	private String goPlace;
	private int amount;
	private boolean goandback;
	private int cost;
	private int moneyBefore;
	private int moneyAfter;
	
	
	
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Ticket(String ticketNo, String memberNo, String fromPlace, String goPlace, int amount, boolean goandback,
			int cost, int moneyBefore, int moneyAfter) {
		super();
		this.ticketNo = ticketNo;
		this.memberNo = memberNo;
		this.fromPlace = fromPlace;
		this.goPlace = goPlace;
		this.amount = amount;
		this.goandback = goandback;
		this.cost = cost;
		this.moneyBefore = moneyBefore;
		this.moneyAfter = moneyAfter;
	}

	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(String ticketNo) {
		this.ticketNo = ticketNo;
	}
	public String getMemberNo() {
		return memberNo;
	}
	public void setMemberNo(String memberNO) {
		this.memberNo = memberNO;
	}
	public String getFromPlace() {
		return fromPlace;
	}
	public void setFromPlace(String fromPlace) {
		this.fromPlace = fromPlace;
	}
	public String getGoPlace() {
		return goPlace;
	}
	public void setGoPlace(String goPlace) {
		this.goPlace = goPlace;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public boolean isGoandback() {
		return goandback;
	}
	public void setGoandback(boolean goandback) {
		this.goandback = goandback;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getMoneyBefore() {
		return moneyBefore;
	}
	public void setMoneyBefore(int moneyBefore) {
		this.moneyBefore = moneyBefore;
	}
	public int getMoneyAfter() {
		return moneyAfter;
	}
	public void setMoneyAfter(int moneyAfter) {
		this.moneyAfter = moneyAfter;
	}
	
	
	
}
